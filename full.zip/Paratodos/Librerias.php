<link href="Paratodos/CSS/bootstrap.css" rel="stylesheet" type="text/css"/>
<link href="Paratodos/CSS/custom.min.css" rel="stylesheet" type="text/css"/>
<link href="Paratodos/CSS/jquery-ui.css" rel="stylesheet" type="text/css"/>
<link href="Paratodos/CSS/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
<link href="Paratodos/CSS/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>

<script src="Paratodos/JS/jquery-1.12.4.js" type="text/javascript"></script>
<script src="Paratodos/JS/jquery-ui.js" type="text/javascript"></script>
<script src="Paratodos/JS/jquery.validate.js" type="text/javascript"></script>
<script src="Paratodos/JS/additional-methods.js" type="text/javascript"></script>
<script src="Paratodos/JS/localization/messages_es.js" type="text/javascript"></script>

<script src="Paratodos/JS/bootstrap.min.js" type="text/javascript"></script>
<script src="Paratodos/JS/popper.min.js" type="text/javascript"></script>
<script src="Paratodos/JS/custom.js" type="text/javascript"></script>
<script src="Paratodos/JS/ajax.js" type="text/javascript"></script>
<script src="Paratodos/JS/Paratodos.js" type="text/javascript"></script>