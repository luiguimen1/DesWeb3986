<div style="display: none;">
    <div id="dialog" title="">
    </div>
    <div id="alertaError">
        <div class="alert alert-dismissible alert-danger"></div>
    </div>
    <div id="alertaInfo">
        <div class="alert alert-dismissible alert-info"></div>
    </div>
    <div id="alertaPosi">
        <div class="alert alert-dismissible alert-success"></div>
    </div>
    <div id="dialog-confirm" title="Solicitud de confirmación">
        <p></p>
    </div>
</div>