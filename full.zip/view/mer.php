<?php
if ($_POST) {
    ?>
    <div style="width: 100%;">
        <center>
            <h1>Esto es mercurio</h1>
        </center>
    </div>
    <?php
} else {
    header("location:./");
}
?>